import static org.junit.Assert.assertEquals;

import org.junit.Test;
import java.lang.reflect.*;

public class CalculatorTest{

	// Replace class and method names
	@Test
	public void testAdd() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Calculator");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("add", int.class, int.class);   
		assertEquals("1+2 equals 3", 3, m.invoke(c, 1, 2));
	}
	
	@Test
	public void testSubtract() throws Exception{
		int m_index = 1;
		Class<?> clazz = Class.forName("Calculator");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("subtract", int.class, int.class);
		assertEquals("2-1 equals 1", 1, m.invoke(c, 2, 1));
	}
	
	@Test
	public void testDivide() throws Exception{
		int m_index = 2;
		Class<?> clazz = Class.forName("Calculator");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("divide", int.class, int.class);	
		assertEquals("4/2 equals 2", 2, m.invoke(c, 4, 2));
	}
	
	@Test
	public void testMultiply() throws Exception{
		int m_index = 3;
		Class<?> clazz = Class.forName("Calculator");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("multiply", int.class, int.class);	
		assertEquals("1*2 equals 2", 2, m.invoke(c, 1, 2));
	}
} 