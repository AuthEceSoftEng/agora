public class Movie{
    public Movie(String title, int id){}
    public String getTitle(){}
} 