import static org.junit.Assert.assertEquals;

import org.junit.Test;
import java.lang.reflect.*;

public class MortgageTest{

	@Test
	public void testMortgage() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Mortgage");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("setRate", double.class);  
		m.invoke(c, 4.5d);
		m_index = 1;
		m = clazz.getDeclaredMethod("setPrincipal", double.class); 
		m.invoke(c, 250000d);
		m_index = 2;
		m = clazz.getDeclaredMethod("setYears", int.class);
		m.invoke(c, 12);
		m_index = 3;
		m = clazz.getDeclaredMethod("getMonthlyPayment");
		double monthly = (double)m.invoke(c);
		assertEquals(2250.02d, monthly, 0.005d);
	}
} 