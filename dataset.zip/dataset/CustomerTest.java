import static org.junit.Assert.assertEquals;

import org.junit.Test;
import java.lang.reflect.*;

public class CustomerTest{

	@Test
	public void testAddress() throws Exception{
        // m_index stores the index of the method that's going to be invoked next
		// the index stated is it's position in source file
		int m_index = 0;
		// the string used here is the source code's class name
		Class<?> clazz = Class.forName("Customer");
		// create a class instance 
		// (when there is no constructor or the constructor doesn't have any arguments)
		Object c = clazz.newInstance();
		// get a method instance using it's name and argument types (fully qualified name)
		Method m = clazz.getDeclaredMethod("setAddress", String.class);  
		// call the method
		m.invoke(c, "test");
		// index of method to be invoked		
		m_index = 1;
		m = clazz.getDeclaredMethod("getAddress");   
		assertEquals("Wrong string!", "test", m.invoke(c));
	}
} 