import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import org.junit.Test;
import java.lang.reflect.*;

public class CreditCardValidatorTest{

	@Test
	public void testIsValid() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("CreditCardValidator");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("isDigit", String.class);
		assertFalse((boolean)m.invoke(c, "1234567890123456"));
	}
} 