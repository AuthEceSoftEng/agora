public class Stack{
    public void pushObject(Object o){}
    public Object popObject(){}
} 