public class Customer{
    public void setAddress(String i){}
    public String getAddress(){}
} 