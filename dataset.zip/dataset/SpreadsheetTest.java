import static org.junit.Assert.assertEquals;

import org.junit.Test;
import java.lang.reflect.*;

public class SpreadsheetTest{

	@Test
	public void testSpreadsheet() throws Exception{

		int m_index = 0;
		Class<?> clazz = Class.forName("Spreadsheet");
		Object c = clazz.newInstance(); 
		Method m = clazz.getDeclaredMethod("put", String.class, String.class);
		m.invoke(c, "nikos", "paixtaras");	  
		m_index = 1;
		m = clazz.getDeclaredMethod("get", String.class);
		assertEquals("Wrong answer", "paixtaras", m.invoke(c, "nikos"));
	}
} 