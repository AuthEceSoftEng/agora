import static org.junit.Assert.assertEquals;

import org.junit.Test;
import java.lang.reflect.*;

public class ArticleTest{

	@Test
	public void testId() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Article");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("setId", int.class);
		m.invoke(c, 1);	
		m_index = 1;
		m = clazz.getDeclaredMethod("getId");			
		assertEquals(1, m.invoke(c));
	}
	
	@Test
	public void testName() throws Exception{
		int m_index = 2;
		Class<?> clazz = Class.forName("Article");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("setName", String.class);
		m.invoke(c, "Nikos");	
		m_index = 3;
		m = clazz.getDeclaredMethod("getName");			
		assertEquals("Nikos", m.invoke(c));
	}
	
	@Test
	public void testPrice() throws Exception{
		int m_index = 4;
		Class<?> clazz = Class.forName("Article");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("setPrice", double.class);
		m.invoke(c, 30.0);	
		m_index = 5;
		m = clazz.getDeclaredMethod("getPrice");			
		assertEquals(30.0, m.invoke(c));
	}
	
} 